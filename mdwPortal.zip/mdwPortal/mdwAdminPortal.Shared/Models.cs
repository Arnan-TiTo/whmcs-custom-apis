using System.Text.Json.Serialization;
namespace mdwAdminPortal.Shared.Models;
public record GetOrderDetailEnvelope(
    [property: JsonPropertyName("error")] string? Error,
    [property: JsonPropertyName("message")] string? Message,
    [property: JsonPropertyName("request_id")] string? RequestId,
    [property: JsonPropertyName("response")] GetOrderDetailResponse? Response
);
public record GetOrderDetailResponse(
    [property: JsonPropertyName("order_list")] List<ShopeeOrder> OrderList
);
public class ShopeeOrder
{
    [JsonPropertyName("order_sn")] public string? OrderSn { get; set; }
    [JsonPropertyName("order_status")] public string? OrderStatus { get; set; }
    [JsonPropertyName("buyer_user_id")] public long? BuyerUserId { get; set; }
    [JsonPropertyName("buyer_username")] public string? BuyerUsername { get; set; }
    [JsonPropertyName("currency")] public string? Currency { get; set; }
    [JsonPropertyName("total_amount")] public long? TotalAmount { get; set; }
    [JsonPropertyName("create_time")] public long? CreateTime { get; set; }
    [JsonPropertyName("pay_time")] public long? PayTime { get; set; }
    [JsonPropertyName("update_time")] public long? UpdateTime { get; set; }
    [JsonPropertyName("payment_method")] public string? PaymentMethod { get; set; }
    [JsonPropertyName("shipping_carrier")] public string? ShippingCarrier { get; set; }
    [JsonPropertyName("fulfillment_flag")] public string? FulfillmentFlag { get; set; }
    [JsonPropertyName("region")] public string? Region { get; set; }
    [JsonPropertyName("recipient_address")] public RecipientAddress? RecipientAddress { get; set; }
    [JsonPropertyName("item_list")] public List<ShopeeOrderItem>? ItemList { get; set; }
    [JsonPropertyName("package_list")] public List<ShopeePackage>? PackageList { get; set; }
}
public class RecipientAddress
{
    [JsonPropertyName("name")] public string? Name { get; set; }
    [JsonPropertyName("phone")] public string? Phone { get; set; }
    [JsonPropertyName("full_address")] public string? FullAddress { get; set; }
    [JsonPropertyName("city")] public string? City { get; set; }
    [JsonPropertyName("district")] public string? District { get; set; }
    [JsonPropertyName("state")] public string? State { get; set; }
    [JsonPropertyName("region")] public string? Region { get; set; }
    [JsonPropertyName("zipcode")] public string? Zipcode { get; set; }
}
public class ShopeeOrderItem
{
    [JsonPropertyName("item_id")] public long? ItemId { get; set; }
    [JsonPropertyName("order_item_id")] public long? OrderItemId { get; set; }
    [JsonPropertyName("item_name")] public string? ItemName { get; set; }
    [JsonPropertyName("item_sku")] public string? ItemSku { get; set; }
    [JsonPropertyName("model_id")] public long? ModelId { get; set; }
    [JsonPropertyName("model_name")] public string? ModelName { get; set; }
    [JsonPropertyName("model_sku")] public string? ModelSku { get; set; }
    [JsonPropertyName("model_quantity_purchased")] public int? ModelQtyPurchased { get; set; }
    [JsonPropertyName("model_original_price")] public decimal? ModelOriginalPrice { get; set; }
    [JsonPropertyName("model_discounted_price")] public decimal? ModelDiscountedPrice { get; set; }
}
public class ShopeePackage
{
    [JsonPropertyName("package_number")] public string? PackageNumber { get; set; }
    [JsonPropertyName("logistics_status")] public string? LogisticsStatus { get; set; }
    [JsonPropertyName("shipping_carrier")] public string? ShippingCarrier { get; set; }
    [JsonPropertyName("parcel_chargeable_weight_gram")] public int? ParcelChargeableWeightGram { get; set; }
    [JsonPropertyName("item_list")] public List<ShopeePackageItem>? ItemList { get; set; }
}
public class ShopeePackageItem
{
    [JsonPropertyName("item_id")] public long? ItemId { get; set; }
    [JsonPropertyName("order_item_id")] public long? OrderItemId { get; set; }
    [JsonPropertyName("model_id")] public long? ModelId { get; set; }
    [JsonPropertyName("model_quantity")] public int? ModelQuantity { get; set; }
    [JsonPropertyName("product_location_id")] public string? ProductLocationId { get; set; }
}