using System.Security.Claims;
using mdwAdminPortal.Web.Settings;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Options;

namespace mdwAdminPortal.Web.Pages;

public class LoginModel : PageModel
{
    private readonly AuthOptions _auth;
    public LoginModel(IOptions<AuthOptions> auth) { _auth = auth.Value; }

    [BindProperty] public string Username { get; set; } = "";
    [BindProperty] public string Password { get; set; } = "";
    public string? Error { get; set; }

    public void OnGet() { }

    public async Task<IActionResult> OnPostAsync()
    {
        if (Username == _auth.Username && Password == _auth.Password)
        {
            var claims = new List<Claim> { new Claim(ClaimTypes.Name, Username) };
            var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            var principal = new ClaimsPrincipal(identity);
            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);
            return RedirectToPage("/Index");
        }
        Error = "Invalid username or password";
        return Page();
    }
}