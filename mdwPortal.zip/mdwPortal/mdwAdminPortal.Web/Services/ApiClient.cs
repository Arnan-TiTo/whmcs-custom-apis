using System.Text.Json;
using mdwAdminPortal.Shared.Models;
using mdwAdminPortal.Web.Settings;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Extensions.Options;

namespace mdwAdminPortal.Web.Services;

public class ApiClient
{
    private readonly HttpClient _http;
    private readonly ApiOptions _opt;
    private readonly JsonSerializerOptions _json = new(JsonSerializerDefaults.Web){PropertyNameCaseInsensitive = true};

    public ApiClient(HttpClient http, IOptions<ApiOptions> opt)
    {
        _http = http;
        _opt = opt.Value;
    }

    public async Task<GetOrderDetailEnvelope?> GetOrderDetailAsync(string orderSn, CancellationToken ct = default)
    {
        var qs = new Dictionary<string, string?>
        {
            ["order_sn_list"] = orderSn
        };
        var url = QueryHelpers.AddQueryString(_opt.Path, qs!);
        using var req = new HttpRequestMessage(HttpMethod.Get, url);
        using var res = await _http.SendAsync(req, ct);
        res.EnsureSuccessStatusCode();
        await using var stream = await res.Content.ReadAsStreamAsync(ct);
        return await JsonSerializer.DeserializeAsync<GetOrderDetailEnvelope>(stream, _json, ct);
    }
}