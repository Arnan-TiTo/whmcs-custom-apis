namespace mdwAdminPortal.Web.Settings
{
    public class AuthOptions
    {
        public string Username { get; set; } = "admin";
        public string Password { get; set; } = "1234";
    }
}