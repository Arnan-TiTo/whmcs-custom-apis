using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using mdwAdminPortal.Shared.Models;
using mdwAdminPortal.Web.Services;

namespace mdwAdminPortal.Web.Pages;

[Authorize]
public class IndexModel : PageModel
{
    private readonly ApiClient _api;
    public IndexModel(ApiClient api) => _api = api;

    [BindProperty]
    public string? OrderSn { get; set; }

    public List<ShopeeOrder>? Orders { get; set; }
    public string? Error { get; set; }

    public void OnGet() { }

    public async Task<IActionResult> OnPostImportAsync(CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(OrderSn))
        {
            Error = "กรุณาใส่ order_sn (1 ค่า)";
            return Page();
        }
        if (OrderSn.Contains(",") || OrderSn.Contains(" "))
        {
            Error = "อนุญาตให้ใส่ได้ทีละ 1 order_sn เท่านั้น (ห้ามคั่นด้วยคอมมา/ช่องว่าง)";
            return Page();
        }

        var env = await _api.GetOrderDetailAsync(OrderSn.Trim(), ct);
        if (env == null)
        {
            Error = "ไม่พบข้อมูล (response ว่าง)";
            return Page();
        }
        if (!string.IsNullOrWhiteSpace(env.Error))
        {
            Error = $"API error: {env.Error} – {env.Message}";
            return Page();
        }

        Orders = env.Response?.OrderList;
        if (Orders == null || Orders.Count == 0)
        {
            Error = "ไม่พบคำสั่งซื้อในระบบ";
        }

        return Page();
    }
}