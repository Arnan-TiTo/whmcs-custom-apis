namespace mdwAdminPortal.Web.Settings
{
    public class ApiOptions
    {
        public string BaseUrl { get; set; } = "http://localhost:5100";
        public string Path { get; set; } = "/api/v2/order/get_order_detail";
    }
}