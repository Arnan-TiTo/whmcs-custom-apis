using System.Text.Json;
using mdwAdminPortal.Shared.Models;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();
app.UseSwagger();
app.UseSwaggerUI();

app.UseStaticFiles();

// Emulate Shopee get_order_detail
app.MapGet("/api/v2/order/get_order_detail", (HttpContext http) =>
{
    var orderSnList = http.Request.Query["order_sn_list"].ToString();
    var orderSn = orderSnList?.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).FirstOrDefault() ?? "2404098R48U37H";
    var samplePath = Path.Combine(app.Environment.WebRootPath ?? "wwwroot", "sample-order.json");
    if (!System.IO.File.Exists(samplePath))
    {
        return Results.Problem("sample-order.json not found", statusCode: 500);
    }
    var json = System.IO.File.ReadAllText(samplePath);
    var env = JsonSerializer.Deserialize<GetOrderDetailEnvelope>(json, new JsonSerializerOptions(JsonSerializerDefaults.Web){PropertyNameCaseInsensitive = true});
    if (env?.Response?.OrderList is { Count: > 0 })
    {
        env.Response.OrderList[0].OrderSn = orderSn;
    }
    return Results.Ok(env);
})
.WithName("GetOrderDetail")
.Produces<GetOrderDetailEnvelope>(StatusCodes.Status200OK);

app.MapGet("/", () => Results.Redirect("/swagger"));
app.Run();