namespace mdwAdminPortal.Web;
public static class TimeUtil
{
    public static DateTimeOffset? FromUnixSeconds(long? seconds)
        => seconds is null or <= 0 ? null : DateTimeOffset.FromUnixTimeSeconds(seconds.Value);
    public static string ToThailandString(this DateTimeOffset? dto)
        => dto is null ? "" : dto.Value.ToOffset(TimeSpan.FromHours(7)).ToString("yyyy-MM-dd HH:mm:ss 'ICT'");
}