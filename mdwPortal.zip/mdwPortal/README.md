# mdwAdminPortal

เดโม UI + API ย่อยจำลอง `get_order_detail` สำหรับ Shopee Open Platform

## รัน API (แนะนำพอร์ต 5100)
```bash
dotnet run --project mdwAdminPortal.Api --urls http://localhost:5100
```
เปิด Swagger ที่ `http://localhost:5100/swagger`

## รัน Web
```bash
dotnet run --project mdwAdminPortal.Web
```
Login: `admin / 1234` (แก้ใน `mdwAdminPortal.Web/appsettings.json`)

หน้า Import: ใส่ `order_sn` ได้ครั้งละ 1 ค่า → Web จะเรียก API ภายในโปรเจ็กต์นี้